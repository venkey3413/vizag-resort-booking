from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    email: EmailStr
    password: str

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ProductOut(BaseModel):
    id: int
    title: str
    description: str
    price: float
    image_url: str

    class Config:
        from_attributes = True

class CartItemIn(BaseModel):
    product_id: int
    quantity: int = 1

class CartItemOut(BaseModel):
    product: ProductOut
    quantity: int

class CartOut(BaseModel):
    id: int
    items: list[CartItemOut]

    class Config:
        from_attributes = True