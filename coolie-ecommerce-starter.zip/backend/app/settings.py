from pydantic_settings import BaseSettings
from pydantic import AnyHttpUrl
from typing import List

class Settings(BaseSettings):
    database_url: str | None = None
    jwt_secret: str = "change-me"
    cors_origins: List[AnyHttpUrl] | list[str] = ["*"]

    class Config:
        env_prefix = ""
        env_file = ".env"
        extra = "ignore"

settings = Settings()