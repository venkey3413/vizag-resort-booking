from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Cart, CartItem, Product, User
from ..schemas import CartItemIn, CartOut
from ..security import get_current_user

router = APIRouter(prefix="/api/cart", tags=["cart"])

def _get_user_cart(db, user: User) -> Cart:
    cart = db.query(Cart).filter(Cart.user_id == user.id).first()
    if not cart:
        cart = Cart(user_id=user.id)
        db.add(cart)
        db.commit()
        db.refresh(cart)
    return cart

@router.get("", response_model=CartOut)
def get_cart(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    cart = _get_user_cart(db, user)
    db.refresh(cart)
    return cart

@router.post("/items", response_model=CartOut)
def add_item(item: CartItemIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    cart = _get_user_cart(db, user)
    product = db.query(Product).filter(Product.id == item.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    existing = db.query(CartItem).filter(CartItem.cart_id == cart.id, CartItem.product_id == item.product_id).first()
    if existing:
        existing.quantity += item.quantity
    else:
        db.add(CartItem(cart_id=cart.id, product_id=item.product_id, quantity=item.quantity))
    db.commit()
    db.refresh(cart)
    return cart

@router.delete("/items/{product_id}", response_model=CartOut)
def remove_item(product_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    cart = _get_user_cart(db, user)
    item = db.query(CartItem).filter(CartItem.cart_id == cart.id, CartItem.product_id == product_id).first()
    if item:
        db.delete(item)
        db.commit()
    db.refresh(cart)
    return cart