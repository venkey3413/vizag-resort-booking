from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, Base, SessionLocal
from .models import Product
from .routers import auth, products, cart

app = FastAPI(title="Coolie API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router)
app.include_router(products.router)
app.include_router(cart.router)

# Create tables & seed data
@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)
    # Seed basic products if empty
    db = SessionLocal()
    try:
        if db.query(Product).count() == 0:
            data = [
                {"id": 1, "title": "Solid Wooden Door", "description": "Durable and elegant door crafted from premium hardwood with natural finish.", "price": 249.00, "image_url": "https://storage.googleapis.com/a1aa/image/1788e5e3-08fc-4c58-f979-479785b8ce12.jpg"},
                {"id": 2, "title": "Wooden Dining Chair", "description": "Comfortable chair with handcrafted wooden frame and soft cushion.", "price": 129.00, "image_url": "https://storage.googleapis.com/a1aa/image/bb63c5ef-8982-42fc-4496-5c3b73e86625.jpg"},
                {"id": 3, "title": "Wooden Coffee Table", "description": "Stylish coffee table with solid wood base and tempered glass top.", "price": 199.00, "image_url": "https://storage.googleapis.com/a1aa/image/2052b993-0bcb-4e4d-2369-bbd940fe5760.jpg"},
                {"id": 4, "title": "Wooden Wall Shelf", "description": "Minimalist wall shelf made from natural wood, perfect for decor and storage.", "price": 89.00, "image_url": "https://storage.googleapis.com/a1aa/image/6e4b3ca6-5746-404d-6a86-2bf0cbfc8673.jpg"},
            ]
            for p in data:
                db.add(Product(**p))
            db.commit()
    finally:
        db.close()