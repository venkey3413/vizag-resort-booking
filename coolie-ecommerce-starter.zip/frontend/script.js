import { Auth, Products, Cart } from './api.js';

// Simple modal for login/register
function promptAuth() {
  const email = prompt("Enter email:");
  if (!email) return null;
  const password = prompt("Enter password:");
  if (!password) return null;
  return { email, password };
}

async function ensureAuth() {
  if (Auth.token()) return true;
  const creds = promptAuth();
  if (!creds) return false;
  try {
    // Try register first; if fail, login
    await Auth.register(creds.email, creds.password);
    return true;
  } catch (e) {
    try {
      await Auth.login(creds.email, creds.password);
      return true;
    } catch (err) {
      alert("Auth failed");
      return false;
    }
  }
}

async function updateCartBadge() {
  const badge = document.querySelector('button[aria-label="Shopping Cart"] span');
  if (!Auth.token()) { badge.textContent = "0"; return; }
  try {
    const cart = await Cart.get();
    const count = cart.items.reduce((sum, it) => sum + it.quantity, 0);
    badge.textContent = String(count);
  } catch {
    badge.textContent = "0";
  }
}

function findProductIdByTitle(products, titleText) {
  const p = products.find(p => p.title.trim().toLowerCase() === titleText.trim().toLowerCase());
  return p ? p.id : null;
}

async function wireAddToCart() {
  const products = await Products.list();

  document.querySelectorAll('article').forEach(card => {
    const titleEl = card.querySelector('h3');
    const btn = card.querySelector('button[aria-label^="Add"]');
    if (!titleEl || !btn) return;
    const title = titleEl.textContent || "";
    const productId = findProductIdByTitle(products, title);
    if (!productId) return;

    btn.addEventListener('click', async () => {
      const ok = await ensureAuth();
      if (!ok) return;
      await Cart.add(productId, 1);
      await updateCartBadge();
      btn.textContent = "Added ✓";
      setTimeout(() => (btn.textContent = "Add to Cart"), 1000);
    });
  });
}

window.addEventListener('DOMContentLoaded', async () => {
  await wireAddToCart();
  await updateCartBadge();
});