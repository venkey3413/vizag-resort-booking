// Simple API helper for Coolie storefront
const API_BASE = (window.API_BASE) || "http://localhost:8000";

export async function api(path, { method = "GET", body, auth = false } = {}) {
  const headers = { "Content-Type": "application/json" };
  const token = localStorage.getItem("coolie_token");
  if (auth && token) headers["Authorization"] = "Bearer " + token;

  const res = await fetch(API_BASE + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`API ${method} ${path} failed: ${res.status} ${txt}`);
  }
  return res.json();
}

export const Auth = {
  async register(email, password) {
    const data = await api("/api/auth/register", { method: "POST", body: { email, password } });
    localStorage.setItem("coolie_token", data.access_token);
    return data;
  },
  async login(email, password) {
    const data = await api("/api/auth/login", { method: "POST", body: { email, password } });
    localStorage.setItem("coolie_token", data.access_token);
    return data;
  },
  logout() {
    localStorage.removeItem("coolie_token");
  },
  token() {
    return localStorage.getItem("coolie_token");
  }
};

export const Products = {
  list() {
    return api("/api/products");
  }
};

export const Cart = {
  get() {
    return api("/api/cart", { auth: true });
  },
  add(product_id, quantity = 1) {
    return api("/api/cart/items", { method: "POST", body: { product_id, quantity }, auth: true });
  },
  remove(product_id) {
    return api(`/api/cart/items/${product_id}`, { method: "DELETE", auth: true });
  }
};