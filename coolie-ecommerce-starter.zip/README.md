# Coolie E‑commerce — FastAPI + PostgreSQL + Vanilla JS

This is a ready-to-run full‑stack starter that turns your static `index.html` into a working e‑commerce prototype with:
- Auth (register/login via JWT)
- Product catalog API (seeded from your featured products)
- Cart API (add/remove items)
- Docker Compose for local dev

## Quick start

1. **Install Docker** (Desktop).
2. In a terminal, go to this folder and run:

```bash
docker compose up --build
```

3. Open the storefront:
- Serve the static frontend with any simple server, e.g.:

```bash
# Option A: VS Code Live Server (or similar)
# Option B: Python http.server
cd frontend
python3 -m http.server 5500
```

4. Visit:
- Frontend: http://localhost:5500/frontend/
- API docs: http://localhost:8000/docs

> The first time you add to cart, you'll be prompted for email/password.
> It will try to register you; if the email already exists, it will login.

## Notes

- API base is `http://localhost:8000`; change it by setting `window.API_BASE` before loading `api.js`.
- Database creds are in `docker-compose.yml`.
- On API startup, the DB seeds 4 products that match your current cards.

## Next steps

- Add real checkout (Stripe test mode).
- Add admin endpoints + product CRUD.
- Replace prompt-based auth with a modal or page.
- Move to a front-end framework (React/Vue/Svelte) when ready.